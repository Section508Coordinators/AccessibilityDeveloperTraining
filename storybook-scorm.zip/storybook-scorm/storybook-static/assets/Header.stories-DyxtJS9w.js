import{f as o}from"./index-iZ8NAl3x.js";import{H as p}from"./Header-DIcx13DZ.js";import"./jsx-runtime-SKoiH9zj.js";import"./index-DJO9vBfz.js";import"./Button-C2b3jLnI.js";const f={title:"Example/Header",component:p,tags:["autodocs"],parameters:{layout:"fullscreen"},args:{onLogin:o(),onLogout:o(),onCreateAccount:o()}},e={args:{user:{name:"Jane Doe"}}},r={};var a,s,t;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    user: {
      name: "Jane Doe"
    }
  }
}`,...(t=(s=e.parameters)==null?void 0:s.docs)==null?void 0:t.source}}};var n,m,c;r.parameters={...r.parameters,docs:{...(n=r.parameters)==null?void 0:n.docs,source:{originalSource:"{}",...(c=(m=r.parameters)==null?void 0:m.docs)==null?void 0:c.source}}};const L=["LoggedIn","LoggedOut"];export{e as LoggedIn,r as LoggedOut,L as __namedExportsOrder,f as default};
