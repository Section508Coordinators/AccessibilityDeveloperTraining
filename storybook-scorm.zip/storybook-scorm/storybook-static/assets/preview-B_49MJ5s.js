const e={parameters:{controls:{matchers:{color:/(background|color)$/i,date:/Date$/}}}};export{e as default};
